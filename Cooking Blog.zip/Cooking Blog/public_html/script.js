document.addEventListener("DOMContentLoaded", function () {
    // Function to update content based on section
    function navigateTo(section) {
        const recipePostsSection = document.getElementById("recipe-posts");
        recipePostsSection.innerHTML = ""; // Clear previous content

        // Load content based on section
        if (section === 'home') {
            // Load home content (image or other content)
            const img = document.createElement("img");
            img.src = "Re.jpeg";
            img.alt = "Delicious Recipe";
            recipePostsSection.appendChild(img);
        } else if (section === 'recipes') {
            // Load recipes content
            // Add your recipe content or fetch it dynamically
        } else if (section === 'cooking-tips') {
            // Load cooking tips content
            // Add your cooking tips content or fetch it dynamically
        } else if (section === 'about') {
            // Load about content
            // Add your about content or fetch it dynamically
        } else if (section === 'contact') {
            // Load contact content
            // Add your contact content or fetch it dynamically
        }
    }

    // Initial load on page load
    navigateTo('home');
});

